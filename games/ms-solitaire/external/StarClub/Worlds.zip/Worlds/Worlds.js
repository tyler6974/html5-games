{
	"PMWorldsListList": [
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "MixedCollection",
				"CollectionPriority": 10
			},
			"WorldId": 106,
			"CompleteBonus": 0,
			"FileName": "world20133622023620.js",
			"ID": "eef3e47d-6360-41c4-a0c6-803f07827861",
			"ImgPath": "Classic.png",
			"Name": "Classic",
			"PMPacks": null,
			"PackAmount": 10,
			"PriceOfUnlocking": 0,
			"SentientId": 100,
			"StarAmount": 190,
			"Theme": "classic"
		},
		{
			"ChallengeAmount": 100,
			"CollectionGroup": {
				"CollectionGroupName": "MixedCollection",
				"CollectionPriority": 50
			},
			"WorldId": 108,
			"CompleteBonus": 0,
			"FileName": "world20131203051230.js",
			"ID": "857116eb-517b-4579-9d2f-66c95af09b1f",
			"ImgPath": "Wild West.png",
			"Name": "WildWestCollectionName",
			"PMPacks": null,
			"PackAmount": 10,
			"PriceOfUnlocking": 50,
			"SentientId": 101,
			"StarAmount": 200,
			"Theme": "western"
		},
		{
			"ChallengeAmount": 110,
			"CollectionGroup": {
				"CollectionGroupName": "MixedCollection",
				"CollectionPriority": 60
			},
			"WorldId": 110,
			"CompleteBonus": 0,
			"FileName": "world20130504040512.js",
			"ID": "cb9b46f9-c9d2-4bdf-a006-f44bb35fb295",
			"ImgPath": "CoralCove.png",
			"Name": "CoralCoveCollectionName",
			"PMPacks": null,
			"PackAmount": 10,
			"PriceOfUnlocking": 140,
			"SentientId": 102,
			"StarAmount": 220,
			"Theme": "aquarium"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "MixedCollection",
				"CollectionPriority": 70
			},
			"WorldId": 107,
			"CompleteBonus": 0,
			"FileName": "world20132423062426.js",
			"ID": "5f6f9a68-544d-4b68-84b0-38f8fe116784",
			"ImgPath": "TropicalBreeze.png",
			"Name": "TropicalBreezeCollectionName",
			"PMPacks": null,
			"PackAmount": 10,
			"PriceOfUnlocking": 290,
			"SentientId": 103,
			"StarAmount": 179,
			"Theme": "beach"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "MixedCollection",
				"CollectionPriority": 80
			},
			"WorldId": 105,
			"CompleteBonus": 0,
			"FileName": "world20134323054301.js",
			"ID": "d93a96dd-b716-4375-ba19-075fab06f2fd",
			"ImgPath": "FallHarvest.png",
			"Name": "FallHarvestCollectionName",
			"PMPacks": null,
			"PackAmount": 10,
			"PriceOfUnlocking": 480,
			"SentientId": 104,
			"StarAmount": 201,
			"Theme": "autumn"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "MixedCollection",
				"CollectionPriority": 90
			},
			"WorldId": 109,
			"CompleteBonus": 0,
			"FileName": "world20130725120740.js",
			"ID": "430cd10b-f563-4d36-b101-20e4ba0fc5f3",
			"ImgPath": "Fable.png",
			"Name": "Fable",
			"PMPacks": null,
			"PackAmount": 10,
			"PriceOfUnlocking": 700,
			"SentientId": 105,
			"StarAmount": 200,
			"Theme": "fable"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "GamesCollection",
				"CollectionPriority": 1
			},
			"WorldId": 103,
			"CompleteBonus": 0,
			"FileName": "worldGameKlondike.js",
			"ID": "8b76ed7c-31c6-44f2-9620-8535839c3783",
			"ImgPath": "Klondike-tile.png",
			"Name": "Klondike",
			"PMPacks": null,
			"PackAmount": 8,
			"PriceOfUnlocking": 0,
			"SentientId": 112,
			"StarAmount": 200,
			"Theme": "classic"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "GamesCollection",
				"CollectionPriority": 2
			},
			"WorldId": 102,
			"CompleteBonus": 0,
			"FileName": "worldGameSpider.js",
			"ID": "9a585e94-7a37-4d41-b4d0-af04dbfc6810",
			"ImgPath": "Spider-tile.png",
			"Name": "Spider",
			"PMPacks": null,
			"PackAmount": 8,
			"PriceOfUnlocking": 0,
			"SentientId": 113,
			"StarAmount": 200,
			"Theme": "classic"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "GamesCollection",
				"CollectionPriority": 3
			},
			"WorldId": 104,
			"CompleteBonus": 0,
			"FileName": "worldGameFreecell.js",
			"ID": "01afe22d-4685-4c39-828e-c1a96959ff25",
			"ImgPath": "FreeCell-tile.png",
			"Name": "FreeCell",
			"PMPacks": null,
			"PackAmount": 8,
			"PriceOfUnlocking": 0,
			"SentientId": 114,
			"StarAmount": 200,
			"Theme": "classic"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "GamesCollection",
				"CollectionPriority": 4
			},
			"WorldId": 111,
			"CompleteBonus": 0,
			"FileName": "worldGamePyramid.js",
			"ID": "0c6154bb-42ec-4a96-9cd4-94b49994eec3",
			"ImgPath": "Pyramid-tile.png",
			"Name": "Pyramid",
			"PMPacks": null,
			"PackAmount": 8,
			"PriceOfUnlocking": 0,
			"SentientId": 115,
			"StarAmount": 200,
			"Theme": "classic"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "GamesCollection",
				"CollectionPriority": 5
			},
			"WorldId": 112,
			"CompleteBonus": 0,
			"FileName": "worldGameTripeaks.js",
			"ID": "6c6fec7f-c771-4c4e-ae52-446e307f34c2",
			"ImgPath": "TriPeaks-tile.png",
			"Name": "TriPeaks",
			"PMPacks": null,
			"PackAmount": 8,
			"PriceOfUnlocking": 0,
			"SentientId": 116,
			"StarAmount": 200,
			"Theme": "classic"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "MixedCollection",
				"CollectionPriority": 40
			},
			"WorldId": 113,
			"CompleteBonus": 0,
			"FileName": "worldEvent25th.js",
			"ID": "2014096e-1bb9-44d6-a81f-30aa4d984e89",
			"ImgPath": "25thAnniversary-tile.png",
			"Name": "25th Anniversary",
			"PMPacks": null,
			"PackAmount": 3,
			"PriceOfUnlocking": 0,
			"SentientId": 117,
			"StarAmount": 40,
			"Theme": "classic"
		},
		{
			"ChallengeAmount": 0,
			"CollectionGroup": {
				"CollectionGroupName": "MixedCollection",
				"CollectionPriority": 15
			},
			"WorldId": 114,
			"CompleteBonus": 0,
			"FileName": "worldDiffEasy.js",
			"ID": "b973ce08-d5ee-46fd-a9b7-6e3407154e91",
			"ImgPath": "Easy-tile.png",
			"Name": "Easy",
			"PMPacks": null,
			"PackAmount": 10,
			"PriceOfUnlocking": 0,
			"SentientId": 118,
			"StarAmount": 80,
			"Theme": "classic"
		}
	],
      "PacksV2":[
              {
                     "ChallengeAmount": 0,
                     "CollectionGroup": {
                           "CollectionGroupName": "MixedCollection",
                           "CollectionPriority": 35
                     },
                     "WorldId": 115,
                     "CompleteBonus": 0,
                     "FileName": "worldEventWin10Anniversary.js",
                     "ID": "ed7b67e3-cd69-4db5-bf7d-0bd21edbd229",
                     "ImgPath": "Windows101stAnniversary-tile.png",
                     "Name": "Windows 10 Anniversary",
                     "PMPacks": null,
                     "PackAmount": 5,
                     "PriceOfUnlocking": 0,
                     "SentientId": 119,
                     "StarAmount": 100,
                     "Theme": "packaged_usertheme_anniversary",
                     "SinceDate": "2016-07-19",
                     "Disabled": "False"
              },
              {
                     "ChallengeAmount": 20,
                     "CollectionGroup": {
                           "CollectionGroupName": "MixedCollection",
                           "CollectionPriority": 25
                     },
                     "WorldId": 116,
                     "CompleteBonus": 0,
                     "FileName": "worldPromoAutumnChill.js",
                     "ID": "748a6ef0-e704-4c98-81cb-8b578383dde1",
                     "ImgPath": "AutumnChill-tile.png",
                     "Name": "Autumn Chill",
                     "PMPacks": null,
                     "PackAmount": 5,
                     "PriceOfUnlocking": 0,
                     "SentientId": 120,
                     "StarAmount": 50,
                     "Theme": "autumn",
                     "SinceDate": "2017-10-11",
                     "Disabled": "False"
              }
       ],
	"CollectionGroupPriorityTable": [
		{
			"CollectionGroupName": "GamesCollection",
			"CollectionGroupPriority": 1
		},
		{
			"CollectionGroupName": "MixedCollection",
			"CollectionGroupPriority": 2
		}
	]
}
