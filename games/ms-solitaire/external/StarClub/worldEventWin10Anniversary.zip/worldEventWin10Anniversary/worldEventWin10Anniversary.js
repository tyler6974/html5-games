{
	"ChallengeAmount": 40,
	"CollectionGroup": {
		"CollectionGroupName": "MixedCollection",
		"CollectionPriority": 35
	},
	"CompleteBonus": 0,
	"FileName": "worldEventWin10Anniversary.js",
	"ID": "ed7b67e3-cd69-4db5-bf7d-0bd21edbd229",
	"ImgPath": "Windows101stAnniversary-tile.png",
	"Name": "Windows 10 Anniversary",
	"PMPacks": [{
		"CompleteBonus": 0,
		"DigitNamePack": null,
		"ID": "f5b9ee19-1078-49e2-9c85-c726e58fe101",
		"ImgPath": "klondike.png",
		"Name": "Klondike",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "987df79b-2cfa-4390-bfc8-1ad01b3e6378",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"18292289788388109239329705625425113417754527356212260734903384361095","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_CARDTOPLAY":"6s","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "9bba51e7-de9a-4282-8339-523bc6d00020",
			"ImgPath": "",
				"Name": "1f1218d9-eae4-4afc-828b-c496c9662709",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "9416e112-68a3-4a17-92e5-05858269fcb8",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"36317250446675928610017379068908279236420048240375210468111504269899","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 10 MOVE Root Tableau1 4 MOVE Root Tableau3 7 MOVE Root Tableau4 3 MOVE Root FaceDown5 1 MOVE Root Tableau5 1 MOVE Root FaceDown6 5 MOVE Root Tableau6 2 MOVE Root Foundation0 2 MOVE Root Foundation1 4 MOVE Root Foundation2 3 MOVE Root Foundation3 2 MOVE Root Waste 5 MOVE Root Stock 3 END","PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "4d51dbe0-b510-4207-91ab-9310a69e1987",
			"ImgPath": "",
				"Name": "9f8e301d-c8c4-40fd-ad8b-9e7992b5ed10",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "78cd53b9-84b2-4214-9c8e-11e38e8a0d7a",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"4","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"61931676510766769604455820721628416494494650709909681776681364826648","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_NUMTOPLAY":"2","PARAM_VALUETOPLAY":"5","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "9a1689d6-7686-4ce6-9074-26ba87fff240",
			"ImgPath": "",
				"Name": "6b74a30d-a54b-4dff-9b91-829a9eb7c711",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "c5f69613-8883-45fa-9a23-a1669f50ad8a",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"26187141322578046584324333880506633551598432503077112779481014446908","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_SCOREREQUIRED":"450","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "339df14b-2e67-4708-9739-5dc8a68c4646",
			"ImgPath": "",
				"Name": "e562a79b-b4a2-408f-9f00-41c16797dacb",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "de23b531-df08-48e0-be17-47ec5e955a32",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"45413049145788127012332748860704052097444915715895522160413211067903","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"3","PARAM_CARDTOPLAY":"8c","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "cf6fc271-fe09-454c-8334-ac24356c3547",
			"ImgPath": "",
				"Name": "da5a7710-57e6-4eb3-a114-4047fc1e760f",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "44af998f-22d0-4a34-b91c-1d44ae4fb444",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"73518182013888564998351291259108288874407767120691679625550636021924","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"3","PARAM_SCOREREQUIRED":"250","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "9ce450b6-c7d1-489a-8c1f-efe3f2fe25d1",
			"ImgPath": "",
				"Name": "53273b8a-7b94-4420-a51e-11534e10622b",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "2189917e-ad0a-4075-8fdd-e99f40ebd2fb",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"27463656651716955112659137363794887552393827503851236520402163830011","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"3","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "7258a62a-44db-4710-9532-cd1b25f6fa5b",
			"ImgPath": "",
				"Name": "1d7c078f-0ca4-4f1a-b969-28db4a2632e4",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "52e66683-767d-4a73-b169-122c0fb4eb63",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"4","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"39762094838825765583761324464523283450968961183655312212321115093542","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"3","PARAM_NUMTOPLAY":"3","PARAM_VALUETOPLAY":"4","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "b29fefd4-2193-462e-8567-07bd0bc384f5",
			"ImgPath": "",
				"Name": "acbed0b3-3180-45f8-bf2b-5c0836ba19c7",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 10,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": null,
		"ID": "0801ce74-554b-40d9-885a-4b570646451b",
		"ImgPath": "spider.png",
		"Name": "Spider",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "599c37bc-231b-46bd-8ec4-ce6b6a1f20d0",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"25142715958072651442347355086402660162713435827972768799451204541389822738487551214711947181047866934853501037182629393275119522146781553318774707351866113536","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_SCOREREQUIRED":"725","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "9fe6809e-00a6-42d3-b22a-fa9cb6b2f714",
			"ImgPath": "",
				"Name": "a8504b14-f482-4f5e-9058-7c078159cfda",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "9d287dea-878c-47b6-990d-0f9c6c38f2f6",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"3911993694490310183338712793566303007857112790858213916130601647222357805955457973145868913860808423193036092862280610688455829350059415939809296440784293992112303566","CHDEF_DealScript":"BEGIN MOVE Root FaceDown0 4 MOVE Root Tableau0 2 MOVE Root FaceDown1 4 MOVE Root Tableau1 10 MOVE Root FaceDown2 3 MOVE Root Tableau2 4 MOVE Root Tableau3 1 MOVE Root Tableau4 1 MOVE Root Tableau5 4 MOVE Root Tableau6 1 MOVE Root Tableau7 3 MOVE Root Tableau8 1 MOVE Root Tableau9 4 MOVE Root Foundation0 13 MOVE Root Foundation1 13 MOVE Root Foundation2 13 MOVE Root Foundation3 13 MOVE Root Stock 10 END","PARAM_SUITS":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "a95474e8-6d71-4fca-bdb3-52396084efa1",
			"ImgPath": "",
				"Name": "07833b9d-fa37-4b79-a071-1efdfa1fddd6",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "0b253310-43a8-4c27-824b-5618271ef4fb",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"2","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Stack Challenge","CHDEF_DeckSeed#0":"234735508640266016271343582797276879945120454138982273848755121471194718104786693485350103718262939327511952214678155331877470735186611353626919973391840105732","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_STACKSREQUIRED":"3","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "1b827de1-b87e-4a48-8d91-d433673f3c33",
			"ImgPath": "",
				"Name": "43418a14-24cf-4005-8cbb-b3d344bfe0b5",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "b0d8d904-d984-42c3-b651-7c56746d38dd",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"13435827972768799451204541389822738487551214711947181047866934853501037182629393275119522146781553318774707351866113536269199733918401057328954373502746297669","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_SCOREREQUIRED":"900","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "82a4a3a2-1714-40f9-8d34-7de5fa59b6c4",
			"ImgPath": "",
				"Name": "0c1217a0-1aff-4f20-9488-ee0017a6c919",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "a194ee6d-2567-48d0-9e85-0328c7271d85",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"197722831869973152512808644459825179826001631640431292327963878756071193753099366833132074261036110434527419650795929208278655824544968273220696949391615","CHDEF_DealScript":null,"PARAM_SUITS":"2","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "457d3e69-2c61-4809-929f-c5659e5525b7",
			"ImgPath": "",
				"Name": "96680acc-ad4e-40e4-9d9e-013f9b19a30b",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "14d7ff48-ffdb-4d7b-aa13-5aa4697d8e8e",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"116495876934275038554533490736730745877444718224432711032785015183420815173623121711403111809279709198349853448359166663114623298497643929514621651050789","CHDEF_DealScript":null,"PARAM_SUITS":"2","PARAM_SCOREREQUIRED":"600","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "d275e43e-e7e4-444b-af90-0e86f45bb9aa",
			"ImgPath": "",
				"Name": "e2c87cab-c4fe-43d0-b095-96735fd81fca",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "1bd8113d-4495-4a2f-b0fc-79a9d0455c96",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"2","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Stack Challenge","CHDEF_DeckSeed#0":"4181534605131812623327773777614570496392205236409306441587842291236973936937084272477859116495876934275038554533490736730745877444718224432711032785015183","CHDEF_DealScript":null,"PARAM_SUITS":"2","PARAM_STACKSREQUIRED":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "b3d62e67-db0a-4aa1-abcc-8346b5930caa",
			"ImgPath": "",
				"Name": "dbd65891-a9f7-4121-906b-36d1a126184d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "3e35b741-f86f-49b0-b033-88804cd16ce1",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
	"GameMode": "Spider",
	"ShowFUE": "False",
	"CHDEF_ChallengeType": "0",
	"CHDEF_AllowedTime": "0",
	"CHDEF_AllowedMoves": "0",
	"CHDEF_ChallengeName": "Solve Challenge",
	"CHDEF_DeckSeed#0": "8178672011921357678392050016046778307751459269366637493022052095732683057744110925408313359841239950852263556689372112175822763721942795169605640491513",
	"CHDEF_DealScript": null,
	"PARAM_SUITS": "2",
	"PARAM_MAXDEALS": "3",
	"HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "4bab9ed3-6867-411e-b53a-5263ab7c92b9",
			"ImgPath": "",
				"Name": "d51d8861-4374-45c5-a973-a5cf171645f2",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 14,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": null,
		"ID": "5e779148-ae6b-4bbd-8533-8672d8525a56",
		"ImgPath": "freecell.png",
		"Name": "FreeCell",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "9fe21d49-c90c-4bf5-af73-a0ae51dc8773",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"79825825397905469082234151693683596920295671282774178133678978121061","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 7 MOVE Root Tableau1 2 MOVE Root Tableau2 5 MOVE Root Tableau3 3 MOVE Root Tableau4 11 MOVE Root Tableau5 5 MOVE Root Tableau6 7 MOVE Root Tableau7 1 MOVE Root Free2 1 MOVE Root Free3 1 MOVE Root Foundation0 2 MOVE Root Foundation1 1 MOVE Root Foundation2 4 MOVE Root Foundation3 2 END","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "eaa203fb-4139-4d14-83b7-526313d01880",
			"ImgPath": "",
				"Name": "bd54e244-d692-4f78-a96c-1c83e3e5de7f",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "c20f9458-00f0-445e-a781-9c1828898fde",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"8671217265212687972537728002424041871585425341965056254612973171223","CHDEF_DealScript":null,"PARAM_CARDTOPLAY":"10c","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "c3172687-2cf3-4624-bb66-f6d6a417ee9e",
			"ImgPath": "",
				"Name": "67ecd450-9a9c-4a84-9930-fdb561cd8946",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "ddb62b4f-07ca-4253-8b32-c362caf2d127",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"17285979476432206092325230182910524897253804032109070593097862113508","CHDEF_DealScript":null,"PARAM_NUMBERTOPLAY":"2","PARAM_VALUETOPLAY":"6","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "239aa63e-ccb5-462d-9bc3-d44542d71ea5",
			"ImgPath": "",
				"Name": "69a75e9f-c76c-408b-bccd-0889bda6e531",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "beca7850-f04a-4cf6-ae39-3556cbf99f29",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"46594447547850636599173993186695930462843365140022993161243717771401","CHDEF_DealScript":null,"PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "4737ca12-f376-436e-b06c-a6866d2ec650",
			"ImgPath": "",
				"Name": "531d27da-dbcc-4561-ac0e-764b6058ec1f",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "8da79121-e0f5-470a-80d4-b1a20ba7729c",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"65","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"4889386776601398140879511753019740448002417229061830053102089202589","CHDEF_DealScript":null,"PARAM_CARDTOPLAY":"jc","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "f68c2f57-1c6b-4fbc-8a7f-aca1749ed49e",
			"ImgPath": "",
				"Name": "19d74bc3-0488-43bb-a63c-7b658a8548dc",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "f34e2640-9a75-48f8-8e7d-813aaa58c576",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"75","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"1542657333945282552796080116147939231844693238349754883162157197060","CHDEF_DealScript":null,"PARAM_NUMBERTOPLAY":"3","PARAM_VALUETOPLAY":"7","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "77acfa22-8bc7-4721-becb-3901c3a06bd6",
			"ImgPath": "",
				"Name": "b70edce1-0170-4ae7-873a-d672be8d987f",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "2417c38b-3ff6-4e0a-a958-ff7661706e66",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"95","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"28571344175207491653147963261985484277244414269598119826381758611168","CHDEF_DealScript":null,"PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "5f6348f5-f1e7-4e4d-976b-da1193614765",
			"ImgPath": "",
				"Name": "f8721a36-ad02-4558-95f3-f4286c2ce4d7",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "b91332e8-69e2-4a48-af29-c69045e31b7c",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"50","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"32185661724037437819354612591356722592197342494011842300887657897297","CHDEF_DealScript":null,"PARAM_CARDTOPLAY":"8d","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "5f9bc2e7-0897-4d16-8e80-9b67322e24fc",
			"ImgPath": "",
				"Name": "eafc923b-3037-4c29-a785-e9320235a3d8",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 11,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": null,
		"ID": "9abe3b78-875a-4ecd-b8e3-43ab2df4f3d7",
		"ImgPath": "pyramid.png",
		"Name": "Pyramid",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "aab0132a-6634-426d-a0d0-092c9b3d3a66",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "15008071810871877702784790416165859134887824701373285756051944536037",
 "CHDEF_DeckSeed#1": "24691510786280682063523888784802126155815697111915673048043380474178",
 "CHDEF_DeckSeed#2": "35447576606529980338675113046064230197742932803629777295933578206150",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "3a811d94-4aca-4545-a44b-b27f42c3e18c",
			"ImgPath": "",
				"Name": "7e0c4043-f67b-4c00-b261-0b45e09d179d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "7b493936-143f-48c5-92d8-a59fe12d3758",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "64471568055290527328825308177198674793564660053974562848543954371954",
 "CHDEF_DeckSeed#1": "56458699945742204894262424315340294805915356850925847298343481829837",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_SCOREREQUIRED": "800",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "c05175b6-9c09-461f-aab5-2df130c430fc",
			"ImgPath": "",
				"Name": "5df01982-191d-4992-ab6a-8548783de8e6",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "d2c86f9d-c96f-4c6f-a5fa-02c1471dc538",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "4",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "68590269708661416771146247309163769580960131578360994739322730229734",
 "CHDEF_DeckSeed#1": "4117229376569311339792732982066434792682468687479084865751506189808",
 "CHDEF_DeckSeed#2": "58902900678880656131134510866746300917422337328856918227752134076492",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "7",
 "PARAM_VALUETOPLAY": "seven",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "7e48f5a8-51ec-4dfa-9b13-81eb0d91099a",
			"ImgPath": "",
				"Name": "7164431e-796a-426d-b003-3dd1a057cc90",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "3ff8b57c-e24d-44cd-987d-2ec0af75ac76",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "26786868912415523919251094895446531823965434478435506179328414250882",
 "CHDEF_DeckSeed#1": "50779926727401479730479871462875705126116110098520555491551773183595",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "1",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "27b4501a-a377-4e30-bb90-c54dc8c4e0f8",
			"ImgPath": "",
				"Name": "24200250-4f81-4812-b852-faae2bd0df12",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "491a718f-80c8-47c7-b968-2edf452f4034",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "75652281731744407436020780703522392134176798965966217621512050774644",
 "CHDEF_DeckSeed#1": "10890500870277663076147005566192100165370889526763746453054214506669",
 "CHDEF_DeckSeed#2": "77983619156310727643339355962767254665313044442039238982191397803532",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_SCOREREQUIRED": "2600",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "689d1d7f-14fd-433e-b4f1-99e837d749a8",
			"ImgPath": "",
				"Name": "f19f5660-fa99-46fc-b09c-fd32a61fae3a",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "2a517e93-05a1-46ae-8782-f225b4c03c5d",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "4",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "18458686116745361490141419183632520721343085863921592065302147202401",
 "CHDEF_DeckSeed#1": "43840035857112075820209964882570261033608149698410273235833678029718",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_NUMBERTOPLAY": "7",
 "PARAM_VALUETOPLAY": "jack",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "54a7fa18-9ecb-461f-b292-2a5ef8587001",
			"ImgPath": "",
				"Name": "760aae94-9bcc-4eda-a1d0-e33be272b902",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "dc56d181-e64a-47a1-83b1-773e247e5045",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "70831074898516988099717594009075351129359454708388072599012300090597",
 "CHDEF_DeckSeed#1": "19191429408805703320791614296054668207176140618752385129182567596517",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_SCOREREQUIRED": "1800",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "8536f8af-e434-42e4-bec8-0973bebd469c",
			"ImgPath": "",
				"Name": "92ea3e8f-fbb0-4ac5-aef0-2204fe9868a0",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "048cdea9-3df5-4424-9d9c-7fc99bfe75f7",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "2681625623162429989595832016396909219645001160496586172521999332310",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_BOARDSTOCLEAR": "1",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "aaaa4383-ceb1-436f-98ed-3fc85f96436e",
			"ImgPath": "",
				"Name": "c46022df-3a25-4d56-baf7-266c9205a800",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 12,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": null,
		"ID": "622d5258-615e-456e-b4dd-4c0d10ae81f5",
		"ImgPath": "tripeaks.png",
		"Name": "TriPeaks",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "46b0b9b4-46cd-4a10-a0c6-a86453159aab",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "3",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "9896744517841934886045005449196667324607603893562836106620318483014",
 "CHDEF_DeckSeed#1": "19015517169543615326992031770659655059911291810216874794442669249659",
 "CHDEF_DeckSeed#2": "19294050457841065166785328742109814854615446736438986391655113334807",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "7",
 "PARAM_VALUETOPLAY": "three",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "42975b62-ce86-4377-9493-e55c3bd81d1e",
			"ImgPath": "",
				"Name": "e2affb6e-34b1-4bc4-b318-2b62dc3a9e01",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "96940dfd-cd90-4f4a-ada3-7aa8921c604a",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "28112775300212300502390620279712262872184777287226329436076762094513",
 "CHDEF_DeckSeed#1": "1256922207346255734860332046998419958494555636279781824891992622361",
 "CHDEF_DeckSeed#2": "26580467784536257802843358163238790855959016103790938603222479482411",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_SCOREREQUIRED": "27000",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "bb381dad-5ee4-4c61-a6c8-cc2c653557de",
			"ImgPath": "",
				"Name": "e5ce6919-a5e4-4a2c-bdce-bed1bbf6fbd8",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "6a5d5a4a-6080-4f51-ba7f-820c2674a100",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "3",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "59459800664117583385037207477752249177798450057986056290112291518174",
 "CHDEF_DeckSeed#1": "63058094205295478501901153610711531385360706539862389512973176445903",
 "CHDEF_DeckSeed#2": "24947194925412206902522316173721786877711540446989484596951460434790",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "7",
 "PARAM_VALUETOPLAY": "five",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "4b749b6b-4460-4301-9b9d-3ed075ccd349",
			"ImgPath": "",
				"Name": "6c79aa00-7697-4299-b35c-fba9aff94f38",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 150,
				"Completed": false,
				"Difficulty": 2,
				"Key": "65629b9a-caa4-466f-bcfb-02b414a21580",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "37657984945087461283476628594531976460743458427590950779755300103885",
 "CHDEF_DeckSeed#1": "17377502584211234684223769904337280763574801113906630316263568117319",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "1",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "033dfb9b-f923-4098-88f1-9e10ef783ccd",
			"ImgPath": "",
				"Name": "818ba148-8bbb-4df7-a40f-e025a8600662",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "9f4ebff1-a1f1-489f-8de2-9fae84201aa2",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "3",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "26811697012479096614423153821394786317994459992864597491083027384292",
 "CHDEF_DeckSeed#1": "49587671223844971049150935614243572874170389449854527232574255140286",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_NUMBERTOPLAY": "7",
 "PARAM_VALUETOPLAY": "jack",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "fce45fee-c281-4a4f-b175-37e31772694d",
			"ImgPath": "",
				"Name": "083eb164-353c-4dc0-aa15-534fe8ef511d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 200,
				"Completed": false,
				"Difficulty": 3,
				"Key": "4b06529d-eebd-4c6d-8c85-8f79d8be3f77",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "72499538761906616238051286858072878471977137180585437906792510714036",
 "CHDEF_DeckSeed#1": "33052055218796204936856990685500935473988447625700360484752904735696",
 "CHDEF_DeckSeed#2": "66405689368970127910480777891995421032701645242982572376001517091073",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_SCOREREQUIRED": "46000",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "95a8a465-8346-45be-b709-c6b92892c2a1",
			"ImgPath": "",
				"Name": "00a7497f-5f54-4a30-9de8-b02ed918466d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "ca25be83-8da9-4d03-8a53-bbf6712c008e",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "54604841043367298497191691219723798529796848998504541222213245600295",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_BOARDSTOCLEAR": "1",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "e8aaa979-9059-4d6c-8bae-1f0f9e48d627",
			"ImgPath": "",
				"Name": "2a034f1f-b36e-4057-8d4d-91b96264a1f3",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 300,
				"Completed": false,
				"Difficulty": 4,
				"Key": "ad115ef0-e3d1-45e2-ac0b-cd83cf90ef5a",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "21248165824320686948744951174381685712508423892296995850343721495205",
 "CHDEF_DeckSeed#1": "29962974326981163352275676109680980649676728075487683099611820415395",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_SCOREREQUIRED": "40000",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "2521252f-2ced-49e1-a7f8-125ec114ee93",
			"ImgPath": "",
				"Name": "a9529f57-9f07-4019-b5b3-604256caa889",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 13,
		"Theme": null
	}],
	"PackAmount": 0,
	"PriceOfUnlocking": 0,
	"SentientId": 119,
	"StarAmount": 0,
	"Theme": "packaged_usertheme_anniversary",
	"WorldId": 115
}
