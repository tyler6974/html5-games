{
	"ChallengeAmount": 80,
	"CollectionGroup": {
		"CollectionGroupName": "MixedCollection",
		"CollectionPriority": 15
	},
	"CompleteBonus": 0,
	"FileName": "worldDiffEasy.js",
	"ID": "b973ce08-d5ee-46fd-a9b7-6e3407154e91",
	"ImgPath": "Easy-tile.png",
	"Name": "Easy",
	"PMPacks": [{
		"CompleteBonus": 0,
		"DigitNamePack": "I",
		"ID": "8b364f02-f298-4ab4-b647-3413de194863",
		"ImgPath": "klondike.png",
		"Name": "Klondike",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "aa406b54-81fd-4bc3-8216-8daf0dc87b9d",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"39060954568578145639089225078625579334627801745759070310981164378616","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_CARDTOPLAY":"5d","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "d59b2a9a-2725-4332-a27e-d7ddd82d2fb4",
			"ImgPath": "",
				"Name": "746b7a24-4355-4eec-84e6-e1c274ca1cfa",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "93603b7e-5c46-491d-b18e-097b892584d4",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"4","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"67868954947324150131904800320788210928108315308198531313214230385585","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_NUMTOPLAY":"3","PARAM_VALUETOPLAY":"5","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "6078033e-2e79-41e2-b464-bbba6da16cff",
			"ImgPath": "",
				"Name": "2431f65b-fe03-445c-9308-882356a9cd4c",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "981e4acc-08a2-4f96-a16f-58346f50c6b6",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"35865194075235063059357003381753324806181043506466694538162323625869","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_SCOREREQUIRED":"200","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "0bbf727f-70d2-419c-9390-5eda96f60a66",
			"ImgPath": "",
				"Name": "eea775b3-5dae-4b98-b328-4870f6af3717",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "4b3cc3d6-e08d-4cef-bfaa-70ab0dab4e86",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"41293772589395719945451343302839483722319624654459267387148435622668","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 11 MOVE Root Tableau1 4 MOVE Root FaceDown2 1 MOVE Root Tableau2 1 MOVE Root FaceDown3 2 MOVE Root Tableau3 2 MOVE Root FaceDown4 2 MOVE Root Tableau4 1 MOVE Root FaceDown5 1 MOVE Root Tableau5 10 MOVE Root Tableau6 1 MOVE Root Foundation0 2 MOVE Root Foundation1 3 MOVE Root Foundation2 2 MOVE Root Waste 4 MOVE Root Stock 5 END","PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "e12fe17e-4423-495f-a623-e49d4b3c81b5",
			"ImgPath": "",
				"Name": "8771a111-c20c-441f-a090-34e82e4e4076",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "c1a4b62b-c8cb-4894-9eca-5e7ab8e96fea",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"44783150013529097646389968015713899980312201381563118464311207952466","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_CARDTOPLAY":"5s","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "041cec64-a797-4db8-a5cd-8ce9836888a6",
			"ImgPath": "",
				"Name": "512a6434-d3a1-4ac3-ad9c-1485654e0270",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "b8646282-55fa-4bb5-8cc0-a32062a3bf49",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"4","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"77545452594584317080891230868661755549925646661378920692556819671553","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_NUMTOPLAY":"2","PARAM_VALUETOPLAY":"6","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "0064daca-98ed-4016-8b9b-98123489b5e7",
			"ImgPath": "",
				"Name": "282dbbe4-03eb-4974-a7ee-217284be476e",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "deca8317-278b-430b-9ae0-361c7f6de2ef",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"13198135028168334405011512897440482064679901590413900035810964393796","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_SCOREREQUIRED":"250","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "a1351d79-b1f3-43db-8a42-2e5234a57be7",
			"ImgPath": "",
				"Name": "a10c2e4b-f3e8-4270-bfd2-43c70c311587",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "3464a582-585f-4427-a5f5-65c29cf196f3",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"79088389985485135853969077786138487519781225242549245497399236460710","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 1 MOVE Root Tableau1 2 MOVE Root FaceDown2 1 MOVE Root Tableau2 10 MOVE Root Tableau3 3 MOVE Root Tableau4 2 MOVE Root FaceDown5 3 MOVE Root Tableau5 1 MOVE Root FaceDown6 6 MOVE Root Tableau6 1 MOVE Root Foundation0 1 MOVE Root Foundation1 2 MOVE Root Foundation2 2 MOVE Root Waste 17 END","PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "1144ff08-6101-4e76-9cc4-95ddbdd60f6a",
			"ImgPath": "",
				"Name": "ccba06a2-43a5-42ac-8d72-489c5c7abc81",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 10,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "II",
		"ID": "6ec20e10-3f55-4996-ba1d-877f27aef6d1",
		"ImgPath": "klondike.png",
		"Name": "Klondike",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "d39d3333-f86e-4c10-9359-402498506ca8",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"4","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"55008350010671514769804765092532598945055194681300738161298841235138","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_NUMTOPLAY":"2","PARAM_VALUETOPLAY":"6","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "b0d05a08-a3e4-4084-b032-dc19864b3030",
			"ImgPath": "",
				"Name": "820aef01-f774-43aa-8901-8b0e65a2831d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "4a6728fd-6043-4d26-95ed-c31ac3a6d14a",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"79465786838088865044843673285082282993713401191182048915138614560781","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_CARDTOPLAY":"5d","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "d796f987-3c59-4078-96aa-0f5defb76f24",
			"ImgPath": "",
				"Name": "f6cb8b9f-4c3c-4b11-816c-836bad87525d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "461294f4-cf43-4eb1-a46d-4b9829f9e557",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"39932143841065927152716997529030266971711821282433809946362153636630","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_SCOREREQUIRED":"250","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "34e8a2b3-cbcb-4e50-83f0-4b617c2dffb9",
			"ImgPath": "",
				"Name": "03140c47-9501-44c0-ae45-88ac0d008c88",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "b82c5e7e-6d66-4416-adb9-4ab6e0baaca0",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"65200097872063995279030486973471851162863126296125039716425066547370","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 2 MOVE Root Tableau1 5 MOVE Root Tableau2 3 MOVE Root Tableau3 4 MOVE Root Tableau4 4 MOVE Root FaceDown5 3 MOVE Root Tableau5 5 MOVE Root Tableau6 1 MOVE Root Foundation0 3 MOVE Root Foundation1 3 MOVE Root Foundation2 3 MOVE Root Foundation3 2 MOVE Root Waste 13 MOVE Root Stock 1 END","PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "aacc988b-8e4c-4b02-9b8c-66edeae0be19",
			"ImgPath": "",
				"Name": "6c3f0514-418f-4000-a71c-7af36182e9c2",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "e9da68cb-0475-4fa4-8db9-9dcae9021c81",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"4","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"38261904744450367009780771417338932671414896819972640289262052003238","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_NUMTOPLAY":"2","PARAM_VALUETOPLAY":"7","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "dfe54494-736f-4066-bcb0-3631e380e2c0",
			"ImgPath": "",
				"Name": "f94d1314-f913-48a0-afd3-eb05d997e909",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "52d98eda-c51e-47e8-b2fd-3512de83452c",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"9691167051171350974985070883203631022756943008864267818932332300506","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_CARDTOPLAY":"7d","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "18b65598-dcc1-4b55-8608-6d2a383bf3de",
			"ImgPath": "",
				"Name": "64d8281d-5070-4af9-a1e3-b39cbb9e583c",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "11e8a5a8-b468-464b-a827-5db828e0c943",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"7227289047177773600585243897383681567066721852842532627362479920440","CHDEF_DealScript":null,"PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_SCOREREQUIRED":"250","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "12c9d3e4-2684-4986-8477-1653935a641a",
			"ImgPath": "",
				"Name": "bfc466ca-72f1-4b80-ba80-8124e109bf76",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "08a9f87e-b8e6-4967-b1aa-66b84d73d74b",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Klondike","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"69777139461160813494241974021969394481542323059602967162882038606463","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 5 MOVE Root Tableau1 1 MOVE Root FaceDown2 2 MOVE Root Tableau2 1 MOVE Root FaceDown3 1 MOVE Root Tableau3 1 MOVE Root FaceDown5 4 MOVE Root Tableau5 5 MOVE Root FaceDown6 4 MOVE Root Tableau6 6 MOVE Root Foundation0 4 MOVE Root Foundation1 3 MOVE Root Foundation2 4 MOVE Root Waste 7 MOVE Root Stock 4 END","PARAM_SCORING":"STANDARD","PARAM_DRAW":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "6c49da87-4c83-4ab3-a9b0-121dea3763fd",
			"ImgPath": "",
				"Name": "b7c08a9b-fd35-4e42-bd3f-b112e6631b30",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 5,
		"SentientId": 10,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "I",
		"ID": "fd0dc3ab-aeaf-487b-b433-02c1499696c7",
		"ImgPath": "spider.png",
		"Name": "Spider",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "5509a4b6-b0f8-4e95-bf71-54df0e2839f3",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"2","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Stack Challenge","CHDEF_DeckSeed#0":"254344709256451834828915811312920113072221949490221026118632466270557459478538373938933333628245021013804402719455318221497068396181910621564061452472789754","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_STACKSREQUIRED":"3","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "0ccc1113-28ae-46a9-a120-70a9cd30b96e",
			"ImgPath": "",
				"Name": "bd231d7c-5a5d-4fc8-b96e-72fad273e195",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "4e08edb0-cca0-4647-b1cc-0e58a6c5f59f",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"61764465388746464916169599105998289410885622253628365377106691605238080924831307384563323063030351450702941306720071868954771411214284225939797891652544456","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_SCOREREQUIRED":"700","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "25e639eb-88e0-44d5-b947-41c86d08b419",
			"ImgPath": "",
				"Name": "ab38b84d-0168-4baf-8d4c-0e26c1af47a5",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "9886fc0d-bca9-4466-b0d2-7db838abf6fd",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"6980091882079540176991194512648305109809459043693576892272924206595232551156632597950254818557053976664556319936196238805513213308055115513751709800485943046852605410","CHDEF_DealScript":"BEGIN MOVE Root FaceDown0 2 MOVE Root Tableau0 7 MOVE Root FaceDown1 2 MOVE Root Tableau1 2 MOVE Root FaceDown2 1 MOVE Root Tableau2 1 MOVE Root Tableau3 2 MOVE Root Tableau5 1 MOVE Root Tableau6 2 MOVE Root Tableau7 5 MOVE Root FaceDown8 2 MOVE Root Tableau8 1 MOVE Root FaceDown9 1 MOVE Root Tableau9 3 MOVE Root Foundation0 13 MOVE Root Foundation1 13 MOVE Root Foundation2 13 MOVE Root Foundation3 13 MOVE Root Stock 20 END","PARAM_SUITS":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "26030c61-7f9c-4529-8949-5dc8be38139e",
			"ImgPath": "",
				"Name": "acc5b4ac-f95d-4794-8b37-aaf752a44247",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "884d1dfb-0eb6-4370-b021-0c368fceea74",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"2","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Stack Challenge","CHDEF_DeckSeed#0":"326287516633855236654220897439229257730619035580125358685701699716131398941851689445576134449618152910588115931108011076689313381674946814401146591498456932","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_STACKSREQUIRED":"3","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "0651f2a3-0732-4f5d-a751-d52fff08ee33",
			"ImgPath": "",
				"Name": "28d226ce-5b0a-4521-9782-2b769790a51e",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "df08d172-2ee9-4785-8d86-94698bba577b",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"26916400551252810943396538648139940765221584548135380292627629710165954103856995289488643429788810833458266591142325730122384504664232776670431465652590711646","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_SCOREREQUIRED":"725","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "a6b048c7-aa84-43b5-b3e7-7479028c85f6",
			"ImgPath": "",
				"Name": "fa2babde-ccc6-4e38-8e13-10662260da30",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "34d504df-f91d-49f2-bf70-5c053427a52d",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"2747202781729635696295431468832605853019315574968422807862255980339853824372133495073605444066323665504680389588203896200177761623908113012565145701706913530537619386","CHDEF_DealScript":"BEGIN MOVE Root FaceDown0 2 MOVE Root Tableau0 2 MOVE Root Tableau2 1 MOVE Root FaceDown3 2 MOVE Root Tableau3 1 MOVE Root FaceDown4 1 MOVE Root Tableau4 8 MOVE Root FaceDown5 3 MOVE Root Tableau5 8 MOVE Root FaceDown6 3 MOVE Root Tableau6 4 MOVE Root FaceDown8 2 MOVE Root Tableau8 1 MOVE Root FaceDown9 3 MOVE Root Tableau9 4 MOVE Root Foundation0 13 MOVE Root Foundation1 13 MOVE Root Foundation2 13 MOVE Root Stock 20 END","PARAM_SUITS":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "0b8c39e9-86e4-4df0-9c7b-cac67cfa8a74",
			"ImgPath": "",
				"Name": "d9a4f867-89bc-4a76-961d-90add0fd221a",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "92c1f2e7-7fbf-4c59-b3b7-b134a3538277",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"2","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Stack Challenge","CHDEF_DeckSeed#0":"154983668744165406219211486452291112452225488007137852310603420037962199583900626157304981755095539155510876133811601883024220173404733313117864922062638194212","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_STACKSREQUIRED":"4","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "58d88891-c041-4c8d-9ad0-3b399154aef7",
			"ImgPath": "",
				"Name": "406d61bf-9f94-4c05-8f25-01741c2fa5b4",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "2020eae6-3624-42fc-b0c9-e1c5f665189a",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"301816443230705331541141985732428408373740732696023841773306396386028338041269632595827943756745931312332499723955327066704464015498366874416540621921148645","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_SCOREREQUIRED":"725","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "3b2a1e74-f4d0-42b8-bd30-2e2f4431955a",
			"ImgPath": "",
				"Name": "70107796-deb9-4926-ae81-cef9a982db71",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 11,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "II",
		"ID": "205f6e16-55ca-40f4-ab98-4fe135944e0c",
		"ImgPath": "spider.png",
		"Name": "Spider",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "ad80f42d-88ae-40b7-86a6-90bc3628c1a1",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"3263813131142170202365680135364426483769447263383659601581747408355553725729682479347885948420771008952911811530499547895609018616287017090705552206500301663516378431","CHDEF_DealScript":"BEGIN MOVE Root FaceDown0 5 MOVE Root Tableau0 1 MOVE Root FaceDown1 3 MOVE Root Tableau1 6 MOVE Root FaceDown2 2 MOVE Root Tableau2 1 MOVE Root FaceDown3 4 MOVE Root Tableau3 1 MOVE Root FaceDown7 1 MOVE Root Tableau7 1 MOVE Root Tableau8 4 MOVE Root FaceDown9 2 MOVE Root Tableau9 4 MOVE Root Foundation0 13 MOVE Root Foundation1 13 MOVE Root Foundation2 13 MOVE Root Stock 30 END","PARAM_SUITS":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "65321d8b-95a1-4816-9467-0cfafcfd9db1",
			"ImgPath": "",
				"Name": "df48ba72-6e9c-4e2e-b69b-0e615e221669",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "447247cf-078d-431d-81d6-cb79269f0a4a",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"2","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Stack Challenge","CHDEF_DeckSeed#0":"609388547253585506637560322912054953968974479536988159302151113374109570774443895255389984437033869444813037920473663608072336029262740990369062812224219","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_STACKSREQUIRED":"4","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "92a020bd-8e73-4517-9776-e2cbe39d42f7",
			"ImgPath": "",
				"Name": "2af4dd0f-d253-4ef5-9ad8-e84ee8ee893d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "7e849074-3aac-4e59-8cb8-c7724ded25e8",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"2316215799266503230917623914173714993373269769629220686343262129144323685543588320653527037313999032738661262514901086408294638822284691506093885472535855066","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_SCOREREQUIRED":"700","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "0e7617b8-2120-4bc4-9149-652536fdce06",
			"ImgPath": "",
				"Name": "ca98f46e-7986-49fb-ace4-3db9eee2b135",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "6b1dcf33-953a-44dd-9746-1044dd48cf4b",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"8430378974332808973898418484424217076949570291242065824838407609885602776489020539526723592129720116774432825465480120289008130313487989629865520052978171429566150209","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 2 MOVE Root Tableau1 2 MOVE Root Tableau2 2 MOVE Root Tableau3 2 MOVE Root Tableau4 12 MOVE Root Tableau5 1 MOVE Root Tableau7 3 MOVE Root Tableau8 3 MOVE Root Tableau9 8 MOVE Root Foundation0 13 MOVE Root Foundation1 13 MOVE Root Foundation2 13 MOVE Root Stock 30 END","PARAM_SUITS":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "e22d92b7-0bc2-4ced-af17-c243c5583829",
			"ImgPath": "",
				"Name": "97b31d12-1fca-4705-a95a-81199d37cf41",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "f7ee32fb-800e-4c26-9b2b-617446a3f089",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"2","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Stack Challenge","CHDEF_DeckSeed#0":"354980625925434470925645183482891581131292011307222194949022102611863246627055745947853837393893333362824502101380440271945531822149706839618191062156406145","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_STACKSREQUIRED":"3","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "54f9b09c-6f0f-4e83-8561-6347060b05c4",
			"ImgPath": "",
				"Name": "0e6172b1-5efd-4a56-888b-7cf06c5025c9",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "b40646e8-da36-405b-a5a8-7a74956e1c44",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Score Challenge","CHDEF_DeckSeed#0":"195022707033365535014230829814695828646176446538874646491616959910599828941088562225362836537710669160523808092483130738456332306303035145070294130672007","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_SCOREREQUIRED":"725","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "aa328cfc-d829-4796-9815-1461bb8c3081",
			"ImgPath": "",
				"Name": "c7404971-1540-4e50-bca1-08878609510d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "2d70053d-7737-44c9-9ef9-4cc4e2f717f1",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"7160661501182647806341564697855147668052933121450743520002469129353071206698874837606600319327071058949125166133894429483800276765949278658712838858236809893523865990","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 2 MOVE Root Tableau2 1 MOVE Root Tableau3 8 MOVE Root Tableau4 4 MOVE Root FaceDown5 3 MOVE Root Tableau5 7 MOVE Root Tableau6 10 MOVE Root Tableau7 7 MOVE Root FaceDown8 2 MOVE Root Tableau8 3 MOVE Root Tableau9 1 MOVE Root Foundation0 13 MOVE Root Foundation1 13 MOVE Root Stock 30 END","PARAM_SUITS":"1","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "8e7570ee-60d8-4f1f-a607-4cf5339355b5",
			"ImgPath": "",
				"Name": "2e074614-ed7b-4c98-a844-87deb84d22b6",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "1e79b977-d30b-47e9-824c-03edf5a872ed",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"Spider","ShowFUE":"False","CHDEF_ChallengeType":"2","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Stack Challenge","CHDEF_DeckSeed#0":"314623950314379766363262875166338552366542208974392292577306190355801253586857016997161313989418516894455761344496181529105881159311080110766893133816749468","CHDEF_DealScript":null,"PARAM_SUITS":"1","PARAM_STACKSREQUIRED":"3","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "c0d490c7-d450-4168-aed8-4a61b6c56206",
			"ImgPath": "",
				"Name": "923e643a-c686-4c5d-bb3f-f8f5a1f638a9",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 5,
		"SentientId": 11,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "I",
		"ID": "6dcce3af-e2bb-440b-aff2-6c24184af575",
		"ImgPath": "freecell.png",
		"Name": "FreeCell",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "caab5568-1723-4d66-9e5d-48e9f1226994",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"31618634249113168658802532151409848992117327683962084617401407528373","CHDEF_DealScript":null,"PARAM_CARDTOPLAY":"5h","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "2851e966-0573-4dac-b5d5-428036c29123",
			"ImgPath": "",
				"Name": "b74a80b4-c9c3-4e6b-9bfe-3395cbaa3b29",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "3733fb12-8d55-43c8-8e97-ad93cf484f2e",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"50781225223949122556511147219312015885145196702601485651059560400398","CHDEF_DealScript":null,"PARAM_NUMBERTOPLAY":"2","PARAM_VALUETOPLAY":"3","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "f87b5002-0445-4b4c-91ea-6bbfc93c9367",
			"ImgPath": "",
				"Name": "1c4959d3-31b0-4336-bbdd-588d7f6c5df0",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "623d52ea-bd44-4d7a-9fa2-e1354bcdd288",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"80655461255778538618532345262452331365168039792187590939057737765489","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 3 MOVE Root Tableau1 5 MOVE Root Tableau2 2 MOVE Root Tableau3 7 MOVE Root Tableau4 8 MOVE Root Tableau5 1 MOVE Root Tableau6 2 MOVE Root Tableau7 4 MOVE Root Free0 1 MOVE Root Free1 1 MOVE Root Foundation0 8 MOVE Root Foundation1 3 MOVE Root Foundation2 2 MOVE Root Foundation3 5 END","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "4d2b3b70-8f8d-4466-ade4-b4d5f69ee9db",
			"ImgPath": "",
				"Name": "44161a3c-d515-4ab1-bfbf-a60b16ffb67c",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "33ec9d3f-6f4a-4ff8-9f0f-5fa9749e4be3",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"34302544088641398858880289455632033342148161444475482983674194396443","CHDEF_DealScript":null,"PARAM_NUMBERTOPLAY":"3","PARAM_VALUETOPLAY":"2","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "240cbc6b-a6fd-40b6-ba1b-195591488225",
			"ImgPath": "",
				"Name": "63b80769-74a2-4379-8c24-c2a3b64b4b48",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "9e20f50b-e43d-49bc-a502-b850a0f6eb6c",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"18721469525783757988747622148336834324595111548423968539012133453757","CHDEF_DealScript":null,"PARAM_CARDTOPLAY":"9d","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "608e8393-ecd8-4e73-b0c2-3847f2302df8",
			"ImgPath": "",
				"Name": "e7a27eff-7b15-4958-bd43-d6704495ad76",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "b800eebe-e136-4969-95f5-dfbf539bc0b9",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"80490797358672618003236180479449613653550464290345399718145317124790","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 4 MOVE Root Tableau1 6 MOVE Root Tableau2 7 MOVE Root Tableau3 7 MOVE Root Tableau4 5 MOVE Root Tableau5 2 MOVE Root Tableau6 1 MOVE Root Free1 1 MOVE Root Free3 1 MOVE Root Foundation0 1 MOVE Root Foundation1 2 MOVE Root Foundation2 13 MOVE Root Foundation3 2 END","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "b0786c9a-6ae9-4d23-ba9d-95729397e131",
			"ImgPath": "",
				"Name": "3dc96423-741e-40c5-92e8-711392b820e2",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "b3d28133-4d97-4455-9ba8-d73f53e95827",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"73899259584751957431538709437584078819529414901969508563463701696074","CHDEF_DealScript":null,"PARAM_CARDTOPLAY":"7h","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "054137b7-b13c-405d-82e9-a125b9cf24a8",
			"ImgPath": "",
				"Name": "3a2370a6-2880-49d5-82e1-7782ed9dfb56",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "416dffa4-b356-4bfe-abdd-d6cfd6d4fda9",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"80530048442292957988976040743045700196019511880408884645548320001030","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 11 MOVE Root Tableau1 3 MOVE Root Tableau2 2 MOVE Root Tableau3 4 MOVE Root Tableau4 6 MOVE Root Tableau5 3 MOVE Root Tableau6 2 MOVE Root Tableau7 6 MOVE Root Foundation0 4 MOVE Root Foundation1 2 MOVE Root Foundation2 5 MOVE Root Foundation3 4 END","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "cbc8ed4e-822e-411d-8104-c9dd27bc9b6e",
			"ImgPath": "",
				"Name": "83ec6ad4-85b1-41b9-99e7-efec6ea8ce63",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 14,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "II",
		"ID": "e105af7c-efcb-46e7-a984-59928b732365",
		"ImgPath": "freecell.png",
		"Name": "FreeCell",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "b7a537d5-7922-4834-876f-e80db45d527e",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"3656667707061123913861585723418039902868479038052078395103516078746","CHDEF_DealScript":null,"PARAM_NUMBERTOPLAY":"3","PARAM_VALUETOPLAY":"2","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "b079e167-b227-440c-95bc-924dad8dbd65",
			"ImgPath": "",
				"Name": "858ec337-d764-464c-99c6-8a329e81fcf3",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "a4897cf7-a9c7-4b8a-9171-77fd18e9155f",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"39685221366063683290539789394342168241555141603605962213643957491246","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 6 MOVE Root Tableau1 3 MOVE Root Tableau2 7 MOVE Root Tableau3 1 MOVE Root Tableau4 3 MOVE Root Tableau5 1 MOVE Root Tableau6 11 MOVE Root Tableau7 5 MOVE Root Free1 1 MOVE Root Free2 1 MOVE Root Free3 1 MOVE Root Foundation0 4 MOVE Root Foundation1 4 MOVE Root Foundation2 4 END","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "465bcb01-6c13-4d6d-bc5b-ed39095efb02",
			"ImgPath": "",
				"Name": "f287eccf-0d9e-4d4f-926c-5860187bd2d1",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "a3ca8f1f-abeb-4a87-b7b1-34fb563336e0",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"65097440591437453344082681337625686659231515817092682454202414930083","CHDEF_DealScript":null,"PARAM_NUMBERTOPLAY":"2","PARAM_VALUETOPLAY":"3","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "2bc5fbb5-d4b4-4ed3-a667-b028826eeb1c",
			"ImgPath": "",
				"Name": "d3068855-2864-4ded-a8c2-8f98c5615fb3",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "8931188f-9213-4486-b0a7-b3f1a506c698",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"24866209272798915928964383627156954288878748949910833498572801556579","CHDEF_DealScript":null,"PARAM_CARDTOPLAY":"4s","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "b0f0bcde-509e-4597-9d96-97f75a319c36",
			"ImgPath": "",
				"Name": "5be33446-4937-4bd7-9200-9c020794b4b9",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "14ebb2e4-debe-4d52-ae0b-2c3efd0163f7",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"78969105459878173170063797408120526772520687904654462106853200648593","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 9 MOVE Root Tableau1 1 MOVE Root Tableau2 1 MOVE Root Tableau3 10 MOVE Root Tableau4 4 MOVE Root Tableau5 2 MOVE Root Tableau6 15 MOVE Root Free0 1 MOVE Root Free1 1 MOVE Root Foundation0 2 MOVE Root Foundation1 2 MOVE Root Foundation2 2 MOVE Root Foundation3 2 END","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "81f153fa-63dd-4f9d-b600-daaf416181be",
			"ImgPath": "",
				"Name": "51ad9882-9623-47cf-a12a-637a2428cf07",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "2b09e363-77ee-466b-8ad0-8c794abcb5f5",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"1","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"57411234568862531827608586614390789766077649496914408732332902909143","CHDEF_DealScript":null,"PARAM_NUMBERTOPLAY":"2","PARAM_VALUETOPLAY":"4","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "143db6ec-be09-41e7-97d9-46c05ab05498",
			"ImgPath": "",
				"Name": "222ccfab-9e48-4e7a-ad51-eafdc26e1375",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "137cdd3f-e184-42e2-a7e1-ae9e08546f9b",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"3","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Card Challenge","CHDEF_DeckSeed#0":"15296130343051627585220181869049620631301577041971680264753372156475","CHDEF_DealScript":null,"PARAM_CARDTOPLAY":"8d","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "8f9184e0-6e5e-4dcc-a231-b861a61ab2be",
			"ImgPath": "",
				"Name": "999d7b25-8349-4dac-b6be-5347181ef938",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "032c45ed-8058-462b-aeea-28e096bb0cb2",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{"GameMode":"FreeCell","ShowFUE":"False","CHDEF_ChallengeType":"0","CHDEF_AllowedTime":"0","CHDEF_AllowedMoves":"0","CHDEF_ChallengeName":"Solve Challenge","CHDEF_DeckSeed#0":"79823931685802181074800831048124308537023216033317963327936320821522","CHDEF_DealScript":"BEGIN MOVE Root Tableau0 12 MOVE Root Tableau1 2 MOVE Root Tableau2 3 MOVE Root Tableau3 4 MOVE Root Tableau4 8 MOVE Root Tableau6 8 MOVE Root Tableau7 7 MOVE Root Foundation0 2 MOVE Root Foundation2 3 MOVE Root Foundation3 3 END","PARAM_MAXDEALS":"3","HasDailyChallenge":"True"}
			},
			"CompleteBonus": 0,
				"ID": "4e1b9de7-2cb1-40ce-895a-bf54250a6a70",
			"ImgPath": "",
				"Name": "49e26b40-37b2-44b5-9bda-dde642248cbc",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 5,
		"SentientId": 14,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "I",
		"ID": "1062cc5d-0c9c-4c47-9b66-51008e0fa662",
		"ImgPath": "pyramid.png",
		"Name": "Pyramid",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "82538d35-75d5-4c46-9f80-88cd88b07e5f",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "4",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "15033062590272781372469356428395793469274451973071172327197536108191",
 "CHDEF_DeckSeed#1": "51748200978166867744761427752196483836842396533385721217259541838228",
 "CHDEF_DeckSeed#2": "32385046681591099865606200067570667565756085740460108030673901679397",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "8",
 "PARAM_VALUETOPLAY": "two",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "ff83eb2f-c452-4a57-a060-fc23f6b99167",
			"ImgPath": "",
				"Name": "139a166d-d9fe-4fba-b8fc-f622d7679251",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "26343c1a-0bd6-436b-98b1-4e4aff469032",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "78993104521467161824661897645716913564220138707504311205832016569599",
 "CHDEF_DeckSeed#1": "52002022329486165306789734383776975730015329650102445774672363676440",
 "CHDEF_DeckSeed#2": "54015528839232345991278844997667729947213877560660990570781981334407",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "452781cd-9764-47c5-a52a-e0cdbda398f9",
			"ImgPath": "",
				"Name": "f018c6d9-e716-465c-942a-6a69f7f5c9ed",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "36567f35-2500-422d-87bc-9bb6c8b46282",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "40033428344168640570999228371071596506692961765919461549793965159222",
 "CHDEF_DeckSeed#1": "50455965979334960017019496467273596601004160723120824712263201284092",
 "CHDEF_DeckSeed#2": "27783093435847978002514226503535419612065931311100384340191961654318",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "1500",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "49454813-cc13-4d77-9ec8-2df412955a78",
			"ImgPath": "",
				"Name": "706f73de-0f77-4442-bc59-e5032bfb28f0",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "0703379b-4b94-4b63-8a98-525fb4971c36",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "4",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "44258600556525925645389230618403188090292474454671189652209278966425",
 "CHDEF_DeckSeed#1": "2373717914385995081377098865154615335372046326829901928081221148506",
 "CHDEF_DeckSeed#2": "77034504026265269700668858780338120479106876836053142581661492369368",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "8",
 "PARAM_VALUETOPLAY": "eight",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "56244275-31d4-4632-82a3-2b4b01fca682",
			"ImgPath": "",
				"Name": "6fdfe07f-f46e-449f-87a6-9c754ad270ac",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "1444bf79-7d1a-46ff-9f7a-4aa1736863c5",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "75088787065976510668194927382833956566656835032814647112357656629859",
 "CHDEF_DeckSeed#1": "51140598760702694939861923838628165790618977600080332835091399184279",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "1",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "ac1b112c-19cd-424b-bfbd-56328c60ce21",
			"ImgPath": "",
				"Name": "ed2373d8-6099-4b44-bdb8-e3287ac79fc3",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "97eff815-53d5-4168-b06c-48849e773a36",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "64771986533141832764896849889505225063324584150307908511911399068340",
 "CHDEF_DeckSeed#1": "7973906557617657837784318174521638775923938155849834577032687183936",
 "CHDEF_DeckSeed#2": "20387787672866830618997332013357191311187123039458204677321340623312",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "1500",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "63623386-f730-4927-a6db-1eef477f58d8",
			"ImgPath": "",
				"Name": "79ee02a1-0f5c-4f51-aefb-4db20906536b",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "81e94dc6-a66c-4c9b-949c-9aca79807dbf",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "4",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "77104900305847630318687546850756795725675622810251942354842902917655",
 "CHDEF_DeckSeed#1": "74126451318725477200902067853031915341499690235604745792923654997783",
 "CHDEF_DeckSeed#2": "60573625561170242163890108800909056764307496703683150392791314987310",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "12",
 "PARAM_VALUETOPLAY": "king",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "36127395-fd7e-4adf-8a6a-4224d0fda72a",
			"ImgPath": "",
				"Name": "4240660e-ce74-4ae3-ba33-8f5db7091772",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "a128d0f7-be5b-47d6-9bcf-f387592fc922",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "12244260630441887497169342928419463973897517352696762865933373047832",
 "CHDEF_DeckSeed#1": "51057928334286731660015097035288440788520547373493178145792895446055",
 "CHDEF_DeckSeed#2": "1217882916761873200736990470054959286553723251458726928813630222793",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "a6ef5b46-17b8-4143-bbc4-66d36997beac",
			"ImgPath": "",
				"Name": "9f396a94-dfdf-4ee9-a7b1-9c2526bc2ea5",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 12,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "II",
		"ID": "be61e74d-233c-4cdf-8617-0c1a59460782",
		"ImgPath": "pyramid.png",
		"Name": "Pyramid",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "db6d4820-9a92-4dad-a8a8-4bac85062179",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "13569049896211936778802465627426085962040927379561134067251393805991",
 "CHDEF_DeckSeed#1": "18271864672628388673335104341171846364435122210456520552782512096951",
 "CHDEF_DeckSeed#2": "13350286934331546966431986149333685313651217797891568640182149984155",
 "CHDEF_DeckSeed#3": "39396691410575102166872057017653106858449808802164454959243950325596",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "2100",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "710bcbe7-3b8d-48ab-908b-be4dbdab49fe",
			"ImgPath": "",
				"Name": "7bd33a6f-27a2-4b14-a81f-d5ad9cde9098",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "12e4c6bf-50aa-4041-8f41-83dd7b1760b9",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "32182402603293701422959660650000464276855060747809860954262751680996",
 "CHDEF_DeckSeed#1": "41119912766987713669969144575727194667260973735336317753021072691218",
 "CHDEF_DeckSeed#2": "40790538069684384950780425792314260281492094083264746574363868238081",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "43dc5453-82ee-4ad6-87d7-b8b9b5d31e2d",
			"ImgPath": "",
				"Name": "dfa59309-4c37-41e3-b31f-b9006f2d3e1f",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "2324687e-ea9c-44de-a52c-df76d6c4f734",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "4",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "13431039109440793682939687152158274113218962078460188529972426020854",
 "CHDEF_DeckSeed#1": "61674922858262646953831508754628780913746803719427308968621513186052",
 "CHDEF_DeckSeed#2": "31435560300257994509369924528220069479129538395541968869904423463402",
 "CHDEF_DeckSeed#3": "56719186257506173651880160541902073588472683227372436260103570247708",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "10",
 "PARAM_VALUETOPLAY": "two",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "e9974075-fb17-4ec6-aca6-67280022b150",
			"ImgPath": "",
				"Name": "2a3da28f-ced2-4111-a0b5-c61cc9b8b047",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "a4ac077b-75b3-4a09-aa4c-8a4a50a3e099",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "11979657515460823994717507814676476041387605034406340450383186411317",
 "CHDEF_DeckSeed#1": "40082545587196834467274066603584668798635490449735915585661889963543",
 "CHDEF_DeckSeed#2": "9157421447419356963802745313758105681151311638990116809783100004129",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "69c63eba-01a3-4358-af01-ae074b4e8c70",
			"ImgPath": "",
				"Name": "29cb05fc-23d1-4d17-94bd-3483b0f6dce7",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "f480ee11-5986-4604-875c-0eb4a9d33802",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "61021511398815599231069881524469414313105521565112403495186502796970",
 "CHDEF_DeckSeed#1": "11944208705991988713919190460382072603322966197889279158076196523175",
 "CHDEF_DeckSeed#2": "747148296385474886971830867772266872831202360665881541952038975724",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "1400",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "c478e21a-c348-411f-9463-ac1ee8229dd2",
			"ImgPath": "",
				"Name": "98a2c832-9832-4c00-a911-3d6da02a9581",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "3ed27708-154f-41f1-a220-589772c2eeef",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "4",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "26867218527236145324580465289234208571355504021381228032523239618691",
 "CHDEF_DeckSeed#1": "74596367029764572125189285495495027733146545673311836241963291629488",
 "CHDEF_DeckSeed#2": "9871720506027117309421091360187254847406035359294459597883144700867",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "8",
 "PARAM_VALUETOPLAY": "king",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "6590b39c-b86e-4962-98d9-162ff2315fd7",
			"ImgPath": "",
				"Name": "0df7c7b0-72ff-4ab5-a7b6-4ee13c18b9a3",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "0586a416-74cf-4429-9447-8122d1a2edf5",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "78644907353401462065023693957251930659564422575062839577867297109099",
 "CHDEF_DeckSeed#1": "1149138426499482651416413848599367207164903957646260999963945779758",
 "CHDEF_DeckSeed#2": "58981388760593073580533434553621559327203940564150423151551439597429",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "e2997663-0ca7-4f80-b905-19562e7a12c7",
			"ImgPath": "",
				"Name": "37625939-cf23-40eb-95aa-bac9498447dc",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "d4123df4-5269-4f79-9fd6-5513a5684374",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "Pyramid",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "6583935615711150056795557727832892068287527098589183560503551681928",
 "CHDEF_DeckSeed#1": "62697837236757047182120266225426180611961180858297460929541856225864",
 "CHDEF_DeckSeed#2": "28874994365909017792451245038395023477077721977427400186931225296423",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "2200",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "5ec5746a-14b2-46f8-8eca-276ede065336",
			"ImgPath": "",
				"Name": "b9f545eb-60d2-4875-b9fd-eb296c06bf72",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 5,
		"SentientId": 12,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "I",
		"ID": "694dda75-2bf1-4509-8b7a-de817d9e903d",
		"ImgPath": "tripeaks.png",
		"Name": "TriPeaks",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "70e005b5-f2ae-4c46-8452-aa772fb3f05a",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "80379337711759414559014270055856145297979778419769745615784021000469",
 "CHDEF_DeckSeed#1": "11872373840003659668121457985106197284550990457460907258951563596069",
 "CHDEF_DeckSeed#2": "13044858172444664061401573188468185941373529378446400332892670284295",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "25000",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "cfe940e3-51a1-4195-b6e0-989efd83a88e",
			"ImgPath": "",
				"Name": "45075f0a-281f-44eb-9580-0b22788d110d",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "127a7ced-8bf5-4d91-8f6a-470c90c659b5",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "3",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "77201915950802689093878696180796676300314754902828001580013074711573",
 "CHDEF_DeckSeed#1": "32029838005570919460982642402358118859303860757052551608172429966065",
 "CHDEF_DeckSeed#2": "2000550439017969735154831512096578393465298885274237191213434072460",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "7",
 "PARAM_VALUETOPLAY": "eight",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "5a728572-f901-41fa-b97a-eabba3fa8064",
			"ImgPath": "",
				"Name": "c745f702-4413-4d91-bafb-0fa245588a8e",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "324898b1-5b45-4e80-9327-5064f9ea7d8e",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "46307999864772186813995277251041026854425779677819999704191171741237",
 "CHDEF_DeckSeed#1": "66449071122077453461630052860012839969162042087462652716241558166573",
 "CHDEF_DeckSeed#2": "43754514428842299151443849414630587867137837870516986519821793235549",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "662e39cc-30a6-403b-aa44-73c9bd6bfce7",
			"ImgPath": "",
				"Name": "730d8295-2e8b-4fe9-a4ff-cbf3725c7322",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "f11f9691-e432-40bd-9844-32642d88ff0d",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "31552523001632898408957920819002920542882154559186907975104094494024",
 "CHDEF_DeckSeed#1": "60652978644740241355731969027166895302966222982340442806451929405136",
 "CHDEF_DeckSeed#2": "64198119921693715364787132590754610626797665155238480501551719884672",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "44000",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "463a363d-847e-4278-b228-dba48ccd4089",
			"ImgPath": "",
				"Name": "b9e9e069-e063-4ab4-ac7d-8c41ef30fab0",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "30b27f0c-84eb-4436-a05e-57134780f742",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "12912757439576725061698061748035166688247459865498002924512065446124",
 "CHDEF_DeckSeed#1": "68416779647975895532005659960563880946395663691623482593323551379749",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "1",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "5a8a317f-ef6b-47ae-80c3-6a856a1f1e8a",
			"ImgPath": "",
				"Name": "bedb414c-3deb-40f9-9bf5-88c8fdd1e3f8",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "bca2b1d2-1642-409d-91db-3418ee193e0f",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "3",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "5181599632108742550407504921762308397332529768926070350182327576038",
 "CHDEF_DeckSeed#1": "24440032039919782943463845748075068566125966762260591344381076712432",
 "CHDEF_DeckSeed#2": "40748681697003730182404956216085279677325881211376967930304245695459",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "9",
 "PARAM_VALUETOPLAY": "ace",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "9652ed18-ce74-473e-b42f-7a6349fb75b5",
			"ImgPath": "",
				"Name": "7290c09c-c599-4587-8d43-2456487ab3e1",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "16438376-9cf1-432e-890b-bdf8542dc9ad",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "47211724964581524944432810458120590035713051685434019387651747781717",
 "CHDEF_DeckSeed#1": "28771899584619581946677800393927738026861277250956186198732477963105",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "1",
 "PARAM_SCOREREQUIRED": "33000",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "7d15a928-6817-494e-8edb-c3f566030007",
			"ImgPath": "",
				"Name": "df0a6653-a8ac-4606-8b20-4d0a2746087c",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "481a9066-fa55-4fe9-a5d0-9d04347417f4",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "17881745236156518949371221930925755225041904961559505685951752143109",
 "CHDEF_DeckSeed#1": "8961822540478290059959886773633707138257587733049191710422279808411",
 "CHDEF_DeckSeed#2": "26451750050369814474263674186522348632363635761801593361241803391982",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "b7841a2a-dbb9-40e3-848b-02de4056efa1",
			"ImgPath": "",
				"Name": "f0ad3e0b-9895-4c17-b8b2-f513432227d2",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 0,
		"SentientId": 13,
		"Theme": null
	},
	{
		"CompleteBonus": 0,
		"DigitNamePack": "II",
		"ID": "aff6476f-4ced-4fb4-aeca-f6966d7b538b",
		"ImgPath": "tripeaks.png",
		"Name": "TriPeaks",
		"PMChallenges": [{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "39cfdd3b-ea5d-443d-b3ec-450bd2bada61",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "24428222217116662922853231889957174570529723722829068898164106931450",
 "CHDEF_DeckSeed#1": "54930223455686751514688901194810683110961267731965640332142210690565",
 "CHDEF_DeckSeed#2": "2153969801502873105749967587023046030470154177909616667363482703586",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "15ca3541-98e5-447a-b9ae-1ca78557391a",
			"ImgPath": "",
				"Name": "69a453f3-8c4c-4765-98bb-c8bdba6cb98f",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "491a3ba8-b481-4447-8796-8b6450fc6dbf",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "67883903950820040061899422995631965533874389822347550022761761465410",
 "CHDEF_DeckSeed#1": "19134721946382667084326445500422792927202883931695098273774482935063",
 "CHDEF_DeckSeed#2": "10345614015382035592856379363412751200553997964224550597889935527564",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "35000",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "40d77b51-962f-4253-9348-0f37cc8d28db",
			"ImgPath": "",
				"Name": "64352f5c-8c4d-48bf-8920-18911602358a",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "8eeb863e-c007-4d77-b7bc-753df88ed699",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "3",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "48411077808803141129845047664346269227943006422064015215091448711256",
 "CHDEF_DeckSeed#1": "59534847719598742442462345997230085771634513530558707796691280886603",
 "CHDEF_DeckSeed#2": "56527127894089216342057950004632502723469147049806574591921721948314",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "8",
 "PARAM_VALUETOPLAY": "jack",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "4a254c95-a954-494d-b3df-723d93bec868",
			"ImgPath": "",
				"Name": "82801239-7698-4911-9796-5fc794e5509a",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "70f3a7e3-9dcd-499e-9049-55bb6e9f810f",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "26180369358212343571285238884261648067720255069055180390577456834418",
 "CHDEF_DeckSeed#1": "63057303246360366629466638767243014545058890921083014110014539997923",
 "CHDEF_DeckSeed#2": "49686534755547618303034877101688965698498649302146469867411211888267",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "b44be2ea-a5f9-4108-8681-860d52999b69",
			"ImgPath": "",
				"Name": "0cf5fb63-3313-41fe-aced-99b7b4dbfd9f",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "e7d7198e-4eb3-4c92-8371-071a15a1eb67",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "3",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "13598565187504566636895747851976234080884531456573907440241507000600",
 "CHDEF_DeckSeed#1": "60932093209292711819349458880679671680181796346434394154161812026263",
 "CHDEF_DeckSeed#2": "67779096512724163859247592255785405745031955983394828521101887616191",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "9",
 "PARAM_VALUETOPLAY": "ace",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "36b2641d-8ea3-476a-ad2a-5165334c0421",
			"ImgPath": "",
				"Name": "b4e45296-861b-428f-be05-3b207708dec3",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "e021bed7-4399-4fc0-82cc-c341a50e5d9c",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "1",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Score Challenge",
 "CHDEF_DeckSeed#0": "54796511071201879992685222668975087671310893304405744708204248701710",
 "CHDEF_DeckSeed#1": "57799490324590262138737506438507274830726904931796105115143217644285",
 "CHDEF_DeckSeed#2": "28906663132692877877100587316251387208690356039046561774510880553742",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_SCOREREQUIRED": "46000",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "37cb036f-9ea5-4105-ba4d-a47d60c22107",
			"ImgPath": "",
				"Name": "744cc4b9-d9c4-42cc-b3fc-5c9ea0218dd7",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "7bc01e13-916f-4025-bd13-27d9630c8033",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "0",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Board Challenge",
 "CHDEF_DeckSeed#0": "12383861189371035286491562340242534452186927510461057721413088889302",
 "CHDEF_DeckSeed#1": "64726391926785644714989143083668602225959574191475972565481028133551",
 "CHDEF_DeckSeed#2": "57819880304258899545198846835289690747080616296517172014671969543223",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_BOARDSTOCLEAR": "2",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "2502cb0b-29b0-41dc-ad73-8291e8afc1be",
			"ImgPath": "",
				"Name": "de77e6ba-5db5-4103-a4a6-542d3282a97c",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		},
		{
			"ChallengeData": {
				"Coins": 100,
				"Completed": false,
				"Difficulty": 1,
				"Key": "b6b89c6b-9e23-42a2-b02a-c8d39571997c",
				"PremiumMultiplier": 0,
				"AdditionalDataNeeded": false,
				"Data":
{
 "GameMode": "TriPeaks",
 "ShowFUE": "False",
 "CHDEF_ChallengeType": "3",
 "CHDEF_AllowedTime": "0",
 "CHDEF_AllowedMoves": "0",
 "CHDEF_ChallengeName": "Card Challenge",
 "CHDEF_DeckSeed#0": "66385096879117810778732522292597937791390143516586237974901345860584",
 "CHDEF_DeckSeed#1": "33531041406813683933299075581603135040626308369090643059081447473010",
 "CHDEF_DeckSeed#2": "15921450535853449014830058832200078222588951669964613738772310620366",
 "CHDEF_DeckScript": null,
 "PARAM_MAXDEALS": "2",
 "PARAM_NUMBERTOPLAY": "8",
 "PARAM_VALUETOPLAY": "nine",
 "HasDailyChallenge": "True"
}
			},
			"CompleteBonus": 0,
				"ID": "3e8ef862-4f91-4222-b21a-5b1a27a8eefe",
			"ImgPath": "",
				"Name": "6ff251c5-9a0d-49a5-856e-e2ea5a25d726",
			"PriceOfUnlocking": 0,
			"SentientId": 0,
			"Theme": null
		}],
		"PriceOfUnlocking": 5,
		"SentientId": 13,
		"Theme": null
	}],
	"PackAmount": 0,
	"PriceOfUnlocking": 0,
	"SentientId": 118,
	"StarAmount": 0,
	"Theme": "",
	"WorldId": 114
}
